// t/test.cpp
#include "CppUTest/TestHarness.h"
#include "code.h"

TEST_GROUP(FirstTestGroup)
{
};

TEST(FirstTestGroup, FirstTest)
{
   FAIL("Fail me!");
   //STRCMP_EQUAL("hello", "world");
   //LONGS_EQUAL(1, 2);
   //CHECK(false);
}
