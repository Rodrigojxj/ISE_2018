// src/code/code.cpp

#include <stdlib.h>
#include "code.h"

int test_func ()
{
  return 1;
}
