// src/main.cpp

#include <stdlib.h>
#include <stdio.h>
#include "code.h"

int main(void)
{
  test_func();
  printf("hello world!\n");
  exit(0);
}
