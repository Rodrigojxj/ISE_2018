// src/code/code.h
#ifndef __code_h__
#define __code_h__
int test_func ();
#endif
