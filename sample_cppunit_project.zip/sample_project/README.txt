export CPPUTEST_HOME=/usr/local/lib
mkdir build ; cd build
cmake -DCOMPILE_TESTS=ON ../
make -j3
